﻿README for DG2XML 1.0.1.0, by Nick_W


What is DG2XML

DGXMLTV was written to translate the UK TV Guide data supplied by DigiGuide.com into an XMLTV format file, suitable for use with SageTV and the excellent XMLTV Import Tool by StéphaneM, which can be found here:

http://forums.sagetv.com/forums/showthread.php?t=17566

DigiGuide costs a small amount per year, but the data provided is far superior to that from the Radio Times, TVTV and Over-The-Air.


How To Install

1) Extract the archive.

2) Copy the "xmltv.dgscheme-web" folder in its entirety into your "Z:\Program Files\DigiGuide TV Guide\schemes\server skins" folder.

3) Enable the web service in DigiGuide:

Tools -> Customize -> Web Service -> Enable Web Service

you do not need to have a password, but you can if you wish. Select the DG2XML skin from in the "Web Skin" section.

4) Copy the DG2XML.exe file to somewhere on you SageTV PC. I use the XMLTV Import Tool folder, but you can put it anywhere you want.

5) Set up XMLTV Import Tool to use DG2XML.exe as its grabber. You should know how to do this if you have previously been using a different grabber.

6) Test by running "DG2XML.exe" from a command prompt. The default arguments will create a file in the current directory called "epgdata.xml" for the last weeks listings and the next two weeks listings, for 500 channels starting at channel 0. To see a list of possible arguments, type "DG2XML -help" at a command prompt.


Supported XML Data

The following data, where available, is provided in the resultant XML file:

Credits (director, actor, guest, writer, producer)
Length of program (length of program, plus start and stop times)
Age rating
Aspect ratio
Star rating (out of 5)
Definition (HDTV)
Sound format
Episode name
Series number
Episode number
Subtitles (including type)
Repeat
Year


Support

See:

http://forums.sagetv.com/forums/showthread.php?t=29627


Version History

1.0.1.0
Added time offset argument (see -help)
Small cosmetic changes

1.0.0.0
Original release.